import 'package:atelier2/counterPage.dart';
import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: CounterPage(),
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
    );
  }
}

